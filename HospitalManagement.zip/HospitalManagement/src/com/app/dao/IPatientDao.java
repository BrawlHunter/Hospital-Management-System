package com.app.dao;

import java.util.Date;
import java.util.List;

import com.app.pojos.Appointment;
import com.app.pojos.Doctor;
import com.app.pojos.Patient;

public interface IPatientDao {
	Patient verifyPatient(String email,String password);
	String registerPatient(Patient p);
	List<Patient> listPatients(); 
	String deletePatient(int pid); 
	 
	List<Doctor> getDoctorBySpecialization(String specialization);
	List<Appointment> bookAppointment(int eid,String appointmentDate,String timeSlot);
	
	Doctor getDoctorById(int eid);
	Patient getPatientById(int pid);
	
	String addNewAppointment(Appointment appbook);
	
	String updatePatient(Patient p);
}
