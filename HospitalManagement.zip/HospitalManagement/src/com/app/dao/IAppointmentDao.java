package com.app.dao;

import java.util.List;

import com.app.pojos.Appointment;
import com.app.pojos.Doctor;


public interface IAppointmentDao {
	
	List<Appointment> listAppointment( int eid);
	List<Appointment> appointment();
	String deletePatient(int pid);
	boolean deleteAppointment(int appointmentId);

}
