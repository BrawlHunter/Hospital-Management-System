package com.app.dao;

import java.util.List;

import com.app.pojos.Doctor;


public interface IDoctorDao {
	Doctor verifyDoctor(String email, String password); 
	List<Doctor> listDoctor(); 
	String registerDoctor(Doctor d);
	String deleteDoctor(int eid); 
}
