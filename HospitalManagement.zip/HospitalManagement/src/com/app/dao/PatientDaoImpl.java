package com.app.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Appointment;
import com.app.pojos.Doctor;
import com.app.pojos.Patient;

@Repository
@Service
@Transactional
public class PatientDaoImpl implements IPatientDao{
	
	@Autowired
	private SessionFactory sf;
	
	@Override
	public Patient verifyPatient(String email, String password) {
		System.out.println("X   Y  Z");
		String jpql="select p from Patient p where p.email=:lemail and p.password=:lpass";
	   Patient p= sf.getCurrentSession().createQuery(jpql, Patient.class).setParameter("lemail", email).setParameter("lpass", password).getSingleResult();
	   System.out.println("heyyy"+p);
	   return p;
	}

	 @Override public String registerPatient(Patient p) 
	 {
		 System.out.println("Register Patient Override"+p);
		 sf.getCurrentSession().persist(p);
	 return "New Patient is added Successfully with ID.::"+p.getPid();
	 }
	
	 @Override public List<Patient> listPatients() { 
		 String jpql="select p from Patient p"; 
		 System.out.println("000000000");
	 List<Patient> p = sf.getCurrentSession().createQuery(jpql, Patient.class).getResultList(); 
	 System.out.println("List Patients Override..");
	 return p;
	 }
	 
	 @Override public String deletePatient(int pid) {
		 Session hs=sf.getCurrentSession(); 
		 Patient p=hs.get(Patient.class, pid); 
		
		
		 if(p!=null)
	 {
			 hs.delete(p); 
			 System.out.println(p);
			 return "Patient Details Deleted with ID.:"+p.getPid(); 
			 }
		 return "Patient Deletion failed: Invalid Patient ID  !!";
	 
	 }
		 

	@Override
	public List<Doctor> getDoctorBySpecialization(String specialization) {
		
		String jpql="select d from Doctor d where specialization=:specialization";
		return sf.getCurrentSession().createQuery(jpql,Doctor.class).setParameter("specialization", specialization).getResultList();
		
	}

	@Override
	public List<Appointment> bookAppointment(int eid, String appointmentDate, String timeSlot) {
		System.out.println("in Appointment List "+eid+" "+" "+ appointmentDate+" " + timeSlot);
		String jpql="select a from Appointment a where a.doctor.eid = :eid and a.appointmentDate = :appointmentDate and a.timeSlot = :timeSlot";
		return sf.getCurrentSession().createQuery(jpql,Appointment.class).setParameter("eid", eid).setParameter("appointmentDate", appointmentDate).setParameter("timeSlot", timeSlot).getResultList();
	}

	@Override
	public Doctor getDoctorById(int eid) {
		String jpql="select d from Doctor d where eid=:eid";
		return sf.getCurrentSession().createQuery(jpql,Doctor.class).setParameter("eid", eid).getSingleResult();
	}

	@Override
	public Patient getPatientById(int pid) {
		String jpql="select p from Patient p where pid=:pid";
		return sf.getCurrentSession().createQuery(jpql,Patient.class).setParameter("pid", pid).getSingleResult();
	}

	@Override
	public String addNewAppointment(Appointment appbook) {
		sf.getCurrentSession().persist(appbook);
		System.out.println("in add new Appointment");
		return "Appointment Booking is Confirmed";
	}

	@Override
	public String updatePatient(Patient p) {
		sf.getCurrentSession().update(p);
		return "Update Override"+p.getPid();
		
	}
	 

	 

}
