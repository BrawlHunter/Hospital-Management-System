package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Appointment;
import com.app.pojos.Doctor;
import com.app.pojos.Patient;

@Repository
@Transactional
public class AppointmentDaoImpl implements IAppointmentDao {
	@Autowired
	private SessionFactory sf;
	
	
	@Override
	public List<Appointment> listAppointment( int eid) {
		System.out.println(eid);
		String jpql="select a from Appointment a where a.doctor.eid=:eid"; 
		 return sf.getCurrentSession().createQuery(jpql, Appointment.class).setParameter("eid", eid).getResultList();
		
	}


	@Override
	public List<Appointment> appointment() {
		System.out.println("In All Appointment List:");
		String jpql="select a from Appointment a";
		 return sf.getCurrentSession().createQuery(jpql, Appointment.class).getResultList();
	}


	@Override
	public boolean deleteAppointment(int appointmentId) {
		Session hs=sf.getCurrentSession(); 
		Appointment a=hs.get(Appointment.class, appointmentId);
		if(a!=null)
		{
			hs.delete(a);
			return true;
		}
		return false;
	}
	

	@Override public String deletePatient(int pid) {
		 Session hs=sf.getCurrentSession(); 
		 Patient p=hs.get(Patient.class, pid); 
		 if(p!=null)
	 {
			 hs.delete(p); 
			 System.out.println(p);
			 return "Patient Details Deleted with ID.:"+p.getPid(); 
			 }
		 return "Patient Deletion failed: Invalid Patient ID  !!";
	 
	 }
}
