package com.app.dao;
import java.util.List;

import javax.print.Doc;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Doctor;
import com.app.pojos.Patient;

@Repository
@Transactional
public class DoctorDaoImpl implements IDoctorDao {
	@Autowired
	private SessionFactory sf;

	@Override
	public Doctor verifyDoctor(String email, String password) {
		System.out.println("X   Y  Z");
		String jpql="select d from Doctor d where d.email=:lemail and d.password=:lpass";
		Doctor d= sf.getCurrentSession().createQuery(jpql, Doctor.class).setParameter("lemail", email).setParameter("lpass", password).getSingleResult();
		System.out.println("After Dr. Query:"+d);
		return d;
	}
	
	 @Override public List<Doctor> listDoctor() { 
		 String jpql="select d from Doctor d where d.etype=:etype"; 
	 return sf.getCurrentSession().createQuery(jpql, Doctor.class).setParameter("etype", "Doctor").getResultList(); }

	@Override
	public String registerDoctor(Doctor d) {
		System.out.println("In Doctor Registration:"+d);
		sf.getCurrentSession().persist(d);
		return "New DR. Added sucessfully with ID"+d.getEid();
	}

	@Override
	public String deleteDoctor(int eid) {
		 Session hs=sf.getCurrentSession(); 
		 Doctor d=hs.get(Doctor.class, eid); 
		
		
		 if(d!=null)
	 {
			 hs.delete(d); 
			 System.out.println(d);
			 return "Doctors Details Deleted with ID.:"+d.getEid(); 
			 }
		 return "Doctors Deletion failed: Invalid Patient ID  !!";
	 
	}

}