package com.app.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.dao.DoctorDaoImpl;
import com.app.dao.IAppointmentDao;
import com.app.dao.IDoctorDao;
import com.app.dao.IPatientDao;
import com.app.pojos.Doctor;
import com.app.pojos.Patient;

@Controller
@Service
@RequestMapping("/admin")
public class adminController {
	@Autowired
	private IDoctorDao dao;
	@Autowired
	private IPatientDao pdao;
	@Autowired
	private IAppointmentDao adao;
	
	
	public adminController() {
		System.out.println("In Admin Controller:");
	}
	
	@GetMapping("/login")
	public String loginForm() {
		System.out.println("In Admin login form:");
		return "/admin/login";
	}
	
	@PostMapping("/login")
	public String verifyDoctor(@RequestParam String lemail, @RequestParam String lpass, HttpSession hs, Model map )
	{
		System.out.println("In Admin login Postmap:");
		
		try{
			Doctor d=dao.verifyDoctor(lemail, lpass);	
			hs.setAttribute("adtls", d);
			
			String s=new String("Admin");
			if(d.getEtype().equals(s)) {
				System.out.println(d);
				map.addAttribute("msg", "Login Successful..");
			return "/admin/welcome";
			}
			else {
				map.addAttribute("msg", "Login Invalid!!");
				return "/admin/login";
			}
		}
		catch(RuntimeException e) {
			map.addAttribute("msg", "Invalid Login!!");
			return "/admin/login";
		}
		
	}
	
	
	@GetMapping("/doctors")
	public String doctorsList(Model map) {
		map.addAttribute("dlist", dao.listDoctor());
		System.out.println("In Doctors List:");
		return "/admin/doctors";
	}
	
	@PostMapping("/doctors")
	public String registerDoctor(/* @RequestParam int eid, */@RequestParam String name, @RequestParam String email, @RequestParam String password,@RequestParam String username, @RequestParam String etype, @RequestParam String phone, @RequestParam String specialization,@RequestParam String dob, @RequestParam int experience,@RequestParam String qualification,@RequestParam int morningSlot, @RequestParam int eveningSlot, Model map)
		{
			System.out.println("In Doctor's registration post mapping:");
			Doctor d=new Doctor(name, email, password, username, etype, phone, specialization, dob, experience, qualification, morningSlot, eveningSlot);
			String s=dao.registerDoctor(d);
			map.addAttribute("dlist", dao.listDoctor());
			return "redirect:/admin/doctors";
		}
	
	
	@GetMapping("/patients")
	public String showpatientsList(Model map,Model map1) {
		System.out.println("In Patients List:");
		map.addAttribute("plist", pdao.listPatients());
		map1.addAttribute("applist", adao.appointment());
		return "/admin/patients";
	}
	
	
	@GetMapping("/deletepatient")
	public String deletePatient(@RequestParam int pid, RedirectAttributes flashMap,
			HttpSession hs) {
		System.out.println("In Patient Delete: " + pid);
		//flashMap.addFlashAttribute("mesg", dao.deleteEmployeeDetails(eid));
		hs.setAttribute("mesg",pdao.deletePatient(pid));
		return "redirect:/admin/patients";
	}
	
	@GetMapping("/deleteapp")
	public String deleteAppointment(@RequestParam int appointmentId) {
		System.out.println("In appointment Delete: " + appointmentId);
		//flashMap.addFlashAttribute("mesg", dao.deleteEmployeeDetails(eid));
		/* hs.setAttribute("mesg",adao.deleteAppointment(appointmentId)); */
		adao.deleteAppointment(appointmentId);
		return "redirect:/admin/patients";
	}
	
	@GetMapping("/deletedoctor")
	public String deleteDoctor(@RequestParam int eid, RedirectAttributes flashMap,
			HttpSession hs) {
		System.out.println("In Patient Delete: " + eid);
		//flashMap.addFlashAttribute("mesg", dao.deleteEmployeeDetails(eid));
		hs.setAttribute("mesg",dao.deleteDoctor(eid));
		return "redirect:/admin/doctors";
	}
	@GetMapping("/logout")
	public String userLogout(HttpSession hs,Model map,HttpServletRequest request,
			HttpServletResponse resp) {
		System.out.println("In Admin Logout..");
		map.addAttribute("alogout",hs.getAttribute("pdtls"));
		resp.setHeader("refresh", "5;url="+request.getContextPath()+"/admin/login");
		//discard session
		hs.invalidate();
		return "/admin/logout";
	}
	
	/*
	 * @GetMapping("/register") public String doctorRegisterForm() {
	 * System.out.println("In Doctors Registration form:"); return
	 * "/admin/register"; }
	 */
	
	
	}
	


