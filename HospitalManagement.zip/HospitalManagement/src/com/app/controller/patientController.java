package com.app.controller;



import java.sql.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.IDoctorDao;
import com.app.dao.IPatientDao;
import com.app.pojos.Appointment;
import com.app.pojos.Doctor;
import com.app.pojos.Patient;

@Controller
@Service
@RequestMapping("/patient")
public class patientController {
	@Autowired
	private JavaMailSender sender;
	@Autowired
	private IPatientDao dao;
	//private IDoctorDao dao1;
	
	public patientController() {
		System.out.println("In Patient Controller..");
	}
	
	@GetMapping("/login")
	public String loginForm() {
		System.out.println("In login form..");
		return "/patient/login";
	}
	
	@PostMapping("/login")
	public String verifyPatient(@RequestParam String lemail, @RequestParam String lpass, HttpSession hs, Model map)
	{
		System.out.println("In Login PostMapping...");
		try {
			
			Patient p=dao.verifyPatient(lemail, lpass);
			hs.setAttribute("pdtls", p);
			map.addAttribute("msg", "Login Successful !!");
			return "/patient/welcome";
		}
		catch(RuntimeException e) {
			map.addAttribute("msg", "Invalid login, Please try again !!");
			return "/patient/login";
		}
		
	}
	
	@GetMapping("/register")
	public String showRegistrationForm() {
		System.out.println("In Registration page:");
		return "/patient/register";
	}
	
	@PostMapping("/register")
	public String registerPatient(@RequestParam String fname,@RequestParam String lname,@RequestParam String email,@RequestParam String contact,@RequestParam int age,@RequestParam String gender,@RequestParam String date,@RequestParam String blood,@RequestParam String pass)
	{
		System.out.println("Register with Details:");
		Patient p=new Patient(fname,lname,email, contact, age, gender,date, blood, pass);
		String s=dao.registerPatient(p);
		return"redirect:/patient/login";
	}
	
	@GetMapping("/appointment")
	public String showAppointmentForm() {
		System.out.println("In Patient Appointment Form:");
		return "/patient/appointment";
	}
	

	@PostMapping("/appointment")
	public String doctorSpecialization(@RequestParam String specialization, HttpSession hs) {

		System.out.println("Processing specialization display Page");
		List<Doctor> d = dao.getDoctorBySpecialization(specialization);
		System.out.println("In Patient Appointment Postmapping:" );
		hs.setAttribute("doclist", d);

		return "/patient/doctorlist";
	}
	
	@GetMapping("/doctorid")
	public String showDoctorId(@RequestParam int eid, HttpSession hs1) {
		System.out.println("Doctor Id" + eid);
		hs1.setAttribute("eid", eid);
		System.out.println("timeslot");
		return "redirect:/patient/timeslot";
	}
	
	@GetMapping("/timeslot")
	public String showTimeSlot(ModelMap map,HttpSession hs) {
		map.put("appbook",new Appointment());
		
		System.out.println("in show timeslot");
		return "/patient/timeslot";
	}

	@PostMapping("/timeslot")
	public String processTimeSlot(@RequestParam int pid,@RequestParam int eid, @ModelAttribute("appbook") Appointment appbook,
			Model map,Model map2) {
		  SimpleMailMessage msg=new SimpleMailMessage();
		System.out.println("in process time slot");
		map.getAttribute("eid");
		System.out.println("eid:"+eid);
		
		List<Appointment> appointment = dao.bookAppointment(eid, appbook.getAppointmentDate(), appbook.getTimeSlot());

		Iterator<Appointment> itr = appointment.iterator();
		System.out.println("Appointments are:");

		/*
		 * int count = 0; while (itr.hasNext()) { count++; }
		 */
		/* System.out.println(count); */
		
		/*
		 * if (count < 5) {
		 */
			Patient p=dao.getPatientById(pid);
			Doctor d=dao.getDoctorById(eid);
			appbook.setDoctor(d);
			appbook.setPatient(p);
			map2.addAttribute("adtls", appbook);
			map.addAttribute("msg2", dao.addNewAppointment(appbook));
			map.addAttribute("pmail", p);
			String email1=p.getEmail();
			String pfname=p.getFname();
			String plname=p.getLname();
			String dname=d.getName();
			String dspec=d.getSpecialization();
	        msg.setTo(email1);
	        msg.setSubject("Sure Cure Hospital");
	        msg.setText("HELLO "+pfname+" "+plname+" ! YOUR APPOINTMENT WITH OUR "+dspec+" Dr. "+dname+" IS CONFIRMED. Thank You!");
	        sender.send(msg);
			return "/patient/confirmBooking";
		
		/*
		 * else { String msg1 = "Booking is full,try for another timeslot";
		 * map.addAttribute("msg1", msg1); return "/patient/tryanotherBooking"; }
		 */

	}
	
	@GetMapping("/patientpage")
	public String showPatientPage() {
		/*
		 * System.out.println("Patient Id" + pid); hs1.setAttribute("pid", pid);
		 */
		System.out.println("Patient Page");
		return "redirect:/patient/patientpage";
	}
	
	@GetMapping("/logout")
	public String userLogout(HttpSession hs,Model map,HttpServletRequest request,
			HttpServletResponse resp) {
		System.out.println("In Patient Logout..");
		map.addAttribute("plogout",hs.getAttribute("pdtls"));
		resp.setHeader("refresh", "5;url="+request.getContextPath()+"/patient/login");
		//discard session
		hs.invalidate();
		return "/patient/logout";
	}

}
