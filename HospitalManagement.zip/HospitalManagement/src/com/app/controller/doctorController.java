package com.app.controller;




import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.IAppointmentDao;
import com.app.dao.IDoctorDao;
import com.app.dao.IPatientDao;
import com.app.pojos.Appointment;
import com.app.pojos.Doctor;

@Controller
@Service
@RequestMapping("/doctor")
public class doctorController {
	@Autowired
	private IPatientDao dao1;
	@Autowired
	private IDoctorDao dao;
	@Autowired
	private IAppointmentDao adao;
	
	public doctorController() {
		System.out.println("In Doctor Controller:");
	}
	
	@GetMapping("/login")
	public String loginForm() {
		System.out.println("In Doctors Login Form:");
		return "/doctor/login";
	}
	
	@PostMapping("/login")
	public String verifyDoctor(@RequestParam String lemail, @RequestParam String lpass, HttpSession hs, Model map)
	{
		
		System.out.println("In Dr. login PostMapping:");
		
		try {
			System.out.println("In Dr. login try block:");
	        Doctor d=dao.verifyDoctor(lemail, lpass);
			hs.setAttribute("ddtls", d);
			System.out.println("In Dr. login After try:");
			System.out.println(d);
			map.addAttribute("msg","Login Successful !!");
			
			return "/doctor/welcome";
			
		}
		catch(RuntimeException e) {
			map.addAttribute("msg", "Invalid login, Please try Again:");
			return "/doctor/login";
		}
		
}	
	@GetMapping("/appointment")
	public String appointmentList(@RequestParam int eid, Model map) {
		System.out.println("In Doctors Appointment List");
		System.out.println(eid);
		/*
		 * Doctor doc=new Doctor(); doc.setEid(eid);
		 */
		/*
		 * List<Appointment> appointment=adao.listAppointment(eid);
		 * System.out.println(appointment);
		 */
		System.out.println(eid);
		map.addAttribute("alist", adao.listAppointment(eid));
		return "/doctor/appointment";
	}
	@GetMapping("/pdetails")
	public String patientDetails(@RequestParam int pid,Model map)
	{
		System.out.println("In Pdetails");
		map.addAttribute("drpdtls", dao1.getPatientById(pid));
		return "/doctor/pdetails";
	}
	
	
	@GetMapping("/logout")
	public String userLogout(HttpSession hs,Model map,HttpServletRequest request,
			HttpServletResponse resp) {
		System.out.println("In Doctor Logout..");
		map.addAttribute("dlogout",hs.getAttribute("ddtls"));
		resp.setHeader("refresh", "5;url="+request.getContextPath()+"/doctor/login");
		//discard session
		hs.invalidate();
		return "/doctor/logout";
	}
	
}
