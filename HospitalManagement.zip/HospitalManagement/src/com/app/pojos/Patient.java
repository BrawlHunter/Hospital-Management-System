package com.app.pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Patient {
	private Integer pid;
	private String fname;
	private String lname;
	private String email;
	private String contact;
	private int age;
	private String gender;
	private String doj;
	private String bloodgroup;
	private String password;
	
	private List<Appointment> appointment= new ArrayList<Appointment>();
	

	
	
	public Patient() {
		//super();
		System.out.println("inside patient cstr");
	}


	public Patient(String fname, String lname, String email, String contact, int age, String gender, String doj,
			String bloodgroup, String password) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.contact = contact;
		this.age = age;
		this.gender = gender;
		this.doj = doj;
		this.bloodgroup = bloodgroup;
		this.password=password;
		
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getPid() {
		return pid;
	}


	public void setPid(Integer pid) {
		this.pid = pid;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}

	//@Temporal(TemporalType.DATE)
	public String getDoj() {
		return doj;
	}


	public void setDoj(String doj) {
		this.doj = doj;
	}


	public String getBloodgroup() {
		return bloodgroup;
	}


	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	
	


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	
@JsonIgnore
	@OneToMany(mappedBy = "patient", cascade = CascadeType.DETACH,orphanRemoval = true, fetch = FetchType.EAGER)
	public List<Appointment> getAppointment() {
		return appointment;
	}


	public void setAppointment(List<Appointment> appointment) {
		this.appointment = appointment;
	}
	
	



	@Override
	public String toString() {
		return "Patient [pid=" + pid + ", fname=" + fname + ", lname=" + lname + ", email=" + email + ", contact="
				+ contact + ", age=" + age + ", gender=" + gender + ", doj=" + doj + ", bloodgroup=" + bloodgroup
				+ ", password=" + password + "]";
	}


	

	
	
}
