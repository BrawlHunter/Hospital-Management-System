package com.app.pojos;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Appointment {
	private Integer appointmentId;
	private String appointmentDate;
	/*
	 * private String appointmentStatus; private String appointmentDone;
	 */
	private String timeSlot;
	private Doctor doctor;
	private Patient patient;
	
	
	public Appointment() {
		//super();
		System.out.println("Appointment Constructor...");
		}


	public Appointment(String appointmentDate, /* String appointmentStatus, String appointmentDone, */String timeSlot, Doctor doctor,
			Patient patient) {
		super();
		this.appointmentDate = appointmentDate;
		/*
		 * this.appointmentStatus = appointmentStatus; this.appointmentDone =
		 * appointmentDone;
		 */
		this.timeSlot=timeSlot;
		this.doctor = doctor;
		this.patient = patient;
	}


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getAppointmentId() {
		return appointmentId;
	}


	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}


	public String getAppointmentDate() {
		return appointmentDate;
	}


	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}


	/*
	 * public String getAppointmentStatus() { return appointmentStatus; }
	 * 
	 * 
	 * public void setAppointmentStatus(String appointmentStatus) {
	 * this.appointmentStatus = appointmentStatus; }
	 * 
	 * 
	 * public String isAppointmentDone() { return appointmentDone; }
	 * 
	 * 
	 * public void setAppointmentDone(String appointmentDone) { this.appointmentDone
	 * = appointmentDone; }
	 */

	
	public String getTimeSlot() {
		return timeSlot;
	}


	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	@ManyToOne
	@JoinColumn(name="eid")
	public Doctor getDoctor() {
		return doctor;
	}


	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	@ManyToOne
	@JoinColumn(name="pid")
	public Patient getPatient() {
		return patient;
	}


	public void setPatient(Patient patient) {
		this.patient = patient;
	}


	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", appointmentDate=" + appointmentDate + ", timeSlot="
				+ timeSlot +  "]";
	}



	

	
	
	
}
