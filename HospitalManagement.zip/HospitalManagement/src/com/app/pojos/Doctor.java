package com.app.pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Doctor {
	
	private Integer eid;
	private String name;
	private String email;
	private String password;
	private String username;
	private String etype;
	private String phone;
	private String specialization;//dr.(nullable)
	private String dob;
	private int exp;
	private String qualification;//dr.(nullable)
	private int morningSlot;
	private int eveningSlot;
	private List<Appointment> appointment= new ArrayList<Appointment>();
	
	public Doctor() {
		System.out.println("Doctor Constructor...!");
	}


	

	public Doctor(String name, String email, String password, String username, String etype, String phone,
			String specialization, String dob, int exp, String qualification, int morningsSlot, int eveningSlot) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.username = username;
		this.etype = etype;
		this.phone = phone;
		this.specialization = specialization;
		this.dob = dob;
		this.exp = exp;
		this.qualification = qualification;
		this.morningSlot=morningsSlot;
		this.eveningSlot=eveningSlot;
	}




	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getEid() {
		return eid;
	}


	public void setEid(Integer eid) {
		this.eid = eid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getEtype() {
		return etype;
	}


	public void setEtype(String etype) {
		this.etype = etype;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	@Column(nullable = true)
	public String getSpecialization() {
		return specialization;
	}


	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}


	
	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}
	
	

	
	public int getExp() {
		return exp;
	}




	public void setExp(int exp) {
		this.exp = exp;
	}



	@Column(nullable = true)
	public String getQualification() {
		return qualification;
	}




	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	

	public int getMorningSlot() {
		return morningSlot;
	}




	public void setMorningSlot(int morningSlot) {
		this.morningSlot = morningSlot;
	}




	public int getEveningSlot() {
		return eveningSlot;
	}




	public void setEveningSlot(int eveningSlot) {
		this.eveningSlot = eveningSlot;
	}




	@OneToMany(mappedBy = "doctor", cascade = CascadeType.DETACH,orphanRemoval = true,fetch = FetchType.EAGER)
	public List<Appointment> getAppointment() {
		return appointment;
	}




	public void setAppointment(List<Appointment> appointment) {
		this.appointment = appointment;
	}




	@Override
	public String toString() {
		return "Doctor [eid=" + eid + ", name=" + name + ", email=" + email + ", password=" + password + ", username="
				+ username + ", etype=" + etype + ", phone=" + phone + ", specialization=" + specialization + ", dob="
				+ dob + ", exp=" + exp + ", qualification=" + qualification + ", morningSlot=" + morningSlot
				+ ", eveningSlot=" + eveningSlot + "]";
	}




	

	
}
